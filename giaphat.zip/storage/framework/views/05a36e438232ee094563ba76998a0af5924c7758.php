
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="title_top">
		<span>Quản lý Loại sản phẩm</span>
	</div>
	<a href="<?php echo e(URL::to('/add-category-form')); ?>">Thêm loại sản phẩm</a>
	<table class="table">
		<thead class="thead-light">
			<tr>
				<th scope="col">#idCategoryProduct</th>
				<th scope="col">categoryName</th>
				<th scope="col">categoryDesc</th>
				<th scope="col">categoryImage</th>
				<th scope="col">Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<th scope="row"><?php echo e($category->idCategoryProduct); ?></th>
				<td><?php echo e($category->categoryName); ?></td>
				<td><?php echo e($category->categoryDesc); ?></td>
				<td>
					<img class="img_small" src="<?php echo e(asset('./img/category/'.$category->categoryImage)); ?>" alt="">
				</td>
				<td>
					<a href="<?php echo e(URL::to('/detail-category/'.$category->idCategoryProduct)); ?>">Xem chi tiết</a>
					<br>
					<a href="<?php echo e(URL::to('/delete-category/'.$category->idCategoryProduct)); ?>">Xóa</a>
					<br>
					<a href="<?php echo e(URL::to('/update-category-form/'.$category->idCategoryProduct)); ?>">Chỉnh sửa</a>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\WORK_SPACE\giaphat\resources\views/admin/pages/category/list_category.blade.php ENDPATH**/ ?>