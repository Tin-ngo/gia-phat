<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- css -->
    <link rel="stylesheet" href="<?php echo e(asset('./web/css/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./web/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./web/css/cuahang.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./web/css/chitietsp.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./web/css/cart.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('./web/css/pay.css')); ?>">
    <!-- themify icons -->
    <link rel="stylesheet" href="./assets/themify-icons/themify-icons.css">
    <!-- fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <title>Gia Phát</title>
</head>

<body>
    <div id="main_home">
        
        <?php echo $__env->make('elements.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="body">
            <div class="body__header">
                <div id="banner">
                    <div class="container banner__wrap">
                        <img src="<?php echo e(asset('img/banner/banner.jpg')); ?>" alt="Banner">
                    </div>
                </div>
                <div id="body__show-category">
                    <div class="container body__show-category__wrap">
                        <!-- category item -->
                        <div class="category-item">
                            <img class="category-item__img" src="<?php echo e(asset('img/logo_giaphat.jpg')); ?>" alt="">
                            <p class="category-item__name">Name</p>
                        </div>
                        <div class="category-item">
                            <img class="category-item__img" src="<?php echo e(asset('img/logo_giaphat.jpg')); ?>" alt="">
                            <p class="category-item__name">Name</p>
                        </div>
                        <div class="category-item">
                            <img class="category-item__img" src="<?php echo e(asset('img/logo_giaphat.jpg')); ?>" alt="">
                            <p class="category-item__name">Name</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- body content -->
            <div class="body-content">
                <!-- best selling products -->
                <div class="body-content__item">
                    <div class="container">
                        <div class="body-content__item__header">
                            <hr class="hr-dashed body-content__item__header__hr">
                            <div class="body-content__item__header__text">
                                <span>Sản phẩm bán chạy</span>
                            </div>
                        </div>
                        <div class="show-product__home">
                            <div class="show-product__home__item">
                                <img src="<?php echo e(asset('img/logo_giaphat.jpg')); ?>" alt="">
                                <p class="name__product">Nội thất nhựa Ecoplast cao cấp tại toàn nhà son đà nẵng</p>
                                <p class="price__product">4,600.000đ</p>
                                <a class="show-product__home__item--btn" href="#">Xem chi tiết</a>
                            </div>
                            <div class="show-product__home__item">
                                <img src="<?php echo e(asset('img/logo_giaphat.jpg')); ?>" alt="">
                                <p class="name__product">Nội thất nhựa Ecoplast cao cấp tại toàn nhà son đà nẵng</p>
                                <p class="price__product">
                                    <span class="price__product--old">5,000.000đ</span>
                                    4,600.000đ
                                </p>
                                <a class="show-product__home__item--btn" href="#">Xem chi tiết</a>
                            </div>
                        </div>
                        <a class="body-content__item--more" href="#">Xem thêm <i
                                class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>

                <!-- Tủ nhựa cao cấp -->
                <div class="body-content__item">
                    <div class="container">
                        <div class="body-content__item__header">
                            <hr class="hr-dashed body-content__item__header__hr">
                            <div class="body-content__item__header__text">
                                <span>TỦ nhựa cao cấp</span>
                            </div>
                        </div>
                        <div class="show-product__home">
                            <div class="show-product__home__item">
                                <img src="<?php echo e(asset('img/logo_giaphat.jpg')); ?>" alt="">
                                <p class="name__product">Nội thất nhựa Ecoplast cao cấp tại toàn nhà son đà nẵng</p>
                                <p class="price__product">4,600.000đ</p>
                                <a class="show-product__home__item--btn" href="#">Xem chi tiết</a>
                            </div>
                            <div class="show-product__home__item">
                                <img src="<?php echo e(asset('img/logo_giaphat.jpg')); ?>" alt="">
                                <p class="name__product">Nội thất nhựa Ecoplast cao cấp tại toàn nhà son đà nẵng</p>
                                <p class="price__product">
                                    <span class="price__product--old">5,000.000đ</span>
                                    4,600.000đ
                                </p>
                                <a class="show-product__home__item--btn" href="#">Xem chi tiết</a>
                            </div>
                        </div>
                        <a class="body-content__item--more" href="#">Xem thêm <i
                                class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>

                <!-- Bàn học sinh và giá đựng sách -->
                <div class="body-content__item">
                    <div class="container">
                        <div class="body-content__item__header">
                            <hr class="hr-dashed body-content__item__header__hr">
                            <div class="body-content__item__header__text">
                                <span>Bàn học sinh và giá đựng sách</span>
                            </div>
                        </div>
                        <div class="show-product__home">
                            <div class="show-product__home__item">
                                <img src="<?php echo e(asset('img/logo_giaphat.jpg')); ?>" alt="">
                                <p class="name__product">Nội thất nhựa Ecoplast cao cấp tại toàn nhà son đà nẵng</p>
                                <p class="price__product">4,600.000đ</p>
                                <a class="show-product__home__item--btn" href="#">Xem chi tiết</a>
                            </div>
                            <div class="show-product__home__item">
                                <img src="<?php echo e(asset('img/logo_giaphat.jpg')); ?>" alt="">
                                <p class="name__product">Nội thất nhựa Ecoplast cao cấp tại toàn nhà son đà nẵng</p>
                                <p class="price__product">
                                    <span class="price__product--old">5,000.000đ</span>
                                    4,600.000đ
                                </p>
                                <a class="show-product__home__item--btn" href="#">Xem chi tiết</a>
                            </div>
                        </div>
                        <a class="body-content__item--more" href="#">Xem thêm <i
                                class="fas fa-angle-double-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
        

        <?php echo $__env->make('elements.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>

    <!-- bootstrap -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
    <!-- javascript -->
    <script src="<?php echo e(asset('./web/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH F:\xampp\htdocs\WORK_SPACE\giaphat\resources\views/index.blade.php ENDPATH**/ ?>